var Bmob = require('bmob.js');
Bmob.initialize("9a22a7cb3217e88cac2e81fe7e88c600", "025c1282712e387a62b2bcd5a970f93c");